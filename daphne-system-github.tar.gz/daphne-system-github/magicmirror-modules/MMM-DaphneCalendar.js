/* MagicMirror²
 * Module: MMM-DaphneCalendar
 * Enhanced Calendar Module for Daphne Smart Display
 * Supports CalDAV, manual event addition, and OCR integration
 * 
 * By: Daphne System
 * MIT Licensed.
 */

Module.register("MMM-DaphneCalendar", {
    defaults: {
        updateInterval: 300000, // 5 minutes
        animationSpeed: 2000,
        fadeSpeed: 4000,
        maximumEntries: 10,
        maximumNumberOfDays: 365,
        displaySymbol: true,
        defaultSymbol: "📅",
        showLocation: true,
        showDescription: false,
        wrapEvents: false,
        wrapLocationEvents: false,
        maxTitleLength: 25,
        maxLocationTitleLength: 25,
        fetchInterval: 60000 * 5, // 5 minutes
        urgency: 7,
        timeFormat: "relative",
        dateFormat: "MMM Do",
        fullDayEventDateFormat: "MMM Do",
        showEnd: false,
        getRelative: 6,
        hidePrivate: false,
        hideOngoing: false,
        colored: false,
        coloredSymbolOnly: false,
        customEvents: [], // Events added via voice or touch
        calendars: [
            {
                symbol: "📅",
                url: "https://calendar.google.com/calendar/ical/your-calendar-id/basic.ics",
                name: "Family Calendar",
                color: "#4285f4"
            }
        ],
        calendarCategories: [
            { name: "Family", color: "#4285f4", icon: "👨‍👩‍👧‍👦" },
            { name: "Work", color: "#34a853", icon: "💼" },
            { name: "Personal", color: "#ea4335", icon: "⭐" },
            { name: "School", color: "#fbbc04", icon: "📚" },
            { name: "Health", color: "#9c27b0", icon: "🏥" },
            { name: "Social", color: "#ff9800", icon: "🎉" }
        ]
    },

    requiresVersion: "2.1.0",

    start: function() {
        Log.info("Starting module: " + this.name);
        
        this.events = [];
        this.customEvents = this.config.customEvents || [];
        this.loaded = false;
        this.error = null;
        
        // Add custom events to the events array
        this.events = this.events.concat(this.customEvents);
        
        this.sendSocketNotification("LOAD_CALENDAR_CONFIG", this.config);
        this.scheduleUpdate();
    },

    getDom: function() {
        const wrapper = document.createElement("div");
        wrapper.className = "daphne-calendar";

        if (this.error) {
            wrapper.innerHTML = `<div class="calendar-error">⚠️ ${this.error}</div>`;
            wrapper.className += " dimmed light small";
            return wrapper;
        }

        if (!this.loaded) {
            wrapper.innerHTML = "Loading calendar...";
            wrapper.className += " dimmed light small";
            return wrapper;
        }

        // Create header
        const header = document.createElement("div");
        header.className = "calendar-header";
        header.innerHTML = `
            <h2>📅 Family Calendar</h2>
            <div class="calendar-date">${new Date().toLocaleDateString('en-US', { 
                weekday: 'long', 
                year: 'numeric', 
                month: 'long', 
                day: 'numeric' 
            })}</div>
        `;
        wrapper.appendChild(header);

        // Create events list
        const eventsList = document.createElement("div");
        eventsList.className = "events-list";

        if (this.events.length === 0) {
            eventsList.innerHTML = '<div class="no-events">No upcoming events 📅</div>';
        } else {
            const sortedEvents = this.sortEvents(this.events);
            const limitedEvents = sortedEvents.slice(0, this.config.maximumEntries);
            
            limitedEvents.forEach(event => {
                const eventElement = this.createEventElement(event);
                eventsList.appendChild(eventElement);
            });
        }

        wrapper.appendChild(eventsList);

        // Add calendar controls
        const controls = document.createElement("div");
        controls.className = "calendar-controls";
        controls.innerHTML = `
            <button class="calendar-btn add-event" onclick="daphneCalendar.showAddEventDialog()">
                ➕ Add Event
            </button>
            <button class="calendar-btn voice-add" onclick="daphneCalendar.startVoiceAdd()">
                🎤 Voice Add
            </button>
            <button class="calendar-btn ocr-add" onclick="daphneCalendar.startOCRAdd()">
                📷 Scan Flyer
            </button>
        `;
        wrapper.appendChild(controls);

        return wrapper;
    },

    createEventElement: function(event) {
        const eventDiv = document.createElement("div");
        eventDiv.className = "calendar-event";
        
        const isToday = this.isToday(event.startDate);
        const isOngoing = this.isOngoing(event);
        const isPast = this.isPast(event);
        
        if (isToday) eventDiv.classList.add("today");
        if (isOngoing) eventDiv.classList.add("ongoing");
        if (isPast) eventDiv.classList.add("past");

        // Get category info
        const category = this.getCategoryInfo(event.category);
        
        // Format time display
        const timeDisplay = this.getTimeDisplay(event);
        
        eventDiv.innerHTML = `
            <div class="event-time" style="color: ${category.color}">
                <span class="event-icon">${category.icon}</span>
                <span class="time-text">${timeDisplay}</span>
            </div>
            <div class="event-content">
                <div class="event-title">${this.truncateText(event.title, this.config.maxTitleLength)}</div>
                ${event.location && this.config.showLocation ? 
                    `<div class="event-location">📍 ${this.truncateText(event.location, this.config.maxLocationTitleLength)}</div>` : ''}
                ${event.description && this.config.showDescription ? 
                    `<div class="event-description">${this.truncateText(event.description, 50)}</div>` : ''}
            </div>
            <div class="event-actions">
                ${event.isCustom ? `
                    <button class="event-action-btn edit" onclick="daphneCalendar.editEvent('${event.id}')">✏️</button>
                    <button class="event-action-btn delete" onclick="daphneCalendar.deleteEvent('${event.id}')">🗑️</button>
                ` : ''}
            </div>
        `;

        return eventDiv;
    },

    getCategoryInfo: function(categoryName) {
        const category = this.config.calendarCategories.find(cat => 
            cat.name.toLowerCase() === (categoryName || '').toLowerCase()
        );
        return category || { name: "Other", color: "#666666", icon: "📅" };
    },

    getTimeDisplay: function(event) {
        const now = new Date();
        const startDate = new Date(event.startDate);
        const endDate = event.endDate ? new Date(event.endDate) : null;

        // Check if it's a full day event
        if (event.fullDayEvent) {
            if (this.isToday(startDate)) {
                return "All Day";
            } else {
                return startDate.toLocaleDateString('en-US', { 
                    month: 'short', 
                    day: 'numeric' 
                });
            }
        }

        // For timed events
        if (this.isToday(startDate)) {
            const timeStr = startDate.toLocaleTimeString('en-US', { 
                hour: '2-digit', 
                minute: '2-digit' 
            });
            
            if (this.isOngoing(event)) {
                return `Now (until ${endDate ? endDate.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }) : 'end'})`;
            } else if (startDate > now) {
                const diffMs = startDate - now;
                const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
                const diffMinutes = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));
                
                if (diffHours > 0) {
                    return `${timeStr} (in ${diffHours}h ${diffMinutes}m)`;
                } else {
                    return `${timeStr} (in ${diffMinutes}m)`;
                }
            } else {
                return timeStr;
            }
        } else {
            // Future dates
            const daysDiff = Math.ceil((startDate - now) / (1000 * 60 * 60 * 24));
            const dateStr = startDate.toLocaleDateString('en-US', { 
                month: 'short', 
                day: 'numeric' 
            });
            const timeStr = startDate.toLocaleTimeString('en-US', { 
                hour: '2-digit', 
                minute: '2-digit' 
            });
            
            if (daysDiff === 1) {
                return `Tomorrow ${timeStr}`;
            } else if (daysDiff <= 7) {
                return `${startDate.toLocaleDateString('en-US', { weekday: 'short' })} ${timeStr}`;
            } else {
                return `${dateStr} ${timeStr}`;
            }
        }
    },

    isToday: function(date) {
        const today = new Date();
        const eventDate = new Date(date);
        return eventDate.toDateString() === today.toDateString();
    },

    isOngoing: function(event) {
        const now = new Date();
        const startDate = new Date(event.startDate);
        const endDate = event.endDate ? new Date(event.endDate) : null;
        
        return startDate <= now && (!endDate || endDate >= now);
    },

    isPast: function(event) {
        const now = new Date();
        const endDate = event.endDate ? new Date(event.endDate) : new Date(event.startDate);
        return endDate < now;
    },

    sortEvents: function(events) {
        return events.sort((a, b) => {
            const dateA = new Date(a.startDate);
            const dateB = new Date(b.startDate);
            return dateA - dateB;
        });
    },

    truncateText: function(text, maxLength) {
        if (!text) return '';
        return text.length > maxLength ? text.substring(0, maxLength) + '...' : text;
    },

    addCustomEvent: function(eventData) {
        const newEvent = {
            id: Date.now().toString(),
            title: eventData.title,
            startDate: eventData.startDate,
            endDate: eventData.endDate || null,
            location: eventData.location || null,
            description: eventData.description || null,
            category: eventData.category || 'Personal',
            fullDayEvent: eventData.fullDayEvent || false,
            isCustom: true,
            createdAt: new Date().toISOString()
        };

        this.customEvents.push(newEvent);
        this.events.push(newEvent);
        this.sendSocketNotification("SAVE_CUSTOM_EVENTS", this.customEvents);
        this.updateDom(this.config.animationSpeed);
    },

    editEvent: function(eventId) {
        const event = this.customEvents.find(e => e.id === eventId);
        if (event) {
            this.sendNotification("SHOW_ALERT", {
                type: "notification",
                title: "Edit Event",
                message: `Editing: ${event.title}`,
                timer: 3000
            });
            // Implementation for edit dialog would go here
        }
    },

    deleteEvent: function(eventId) {
        this.customEvents = this.customEvents.filter(e => e.id !== eventId);
        this.events = this.events.filter(e => e.id !== eventId);
        this.sendSocketNotification("SAVE_CUSTOM_EVENTS", this.customEvents);
        this.updateDom(this.config.animationSpeed);
    },

    scheduleUpdate: function() {
        setInterval(() => {
            this.sendSocketNotification("FETCH_CALENDAR_DATA", this.config);
        }, this.config.updateInterval);
    },

    socketNotificationReceived: function(notification, payload) {
        if (notification === "CALENDAR_EVENTS_LOADED") {
            this.events = payload.events.concat(this.customEvents);
            this.loaded = true;
            this.error = null;
            this.updateDom(this.config.animationSpeed);
        } else if (notification === "CALENDAR_ERROR") {
            this.error = payload.error;
            this.loaded = true;
            this.updateDom(this.config.animationSpeed);
        } else if (notification === "CUSTOM_EVENTS_LOADED") {
            this.customEvents = payload.events || [];
            this.events = this.events.concat(this.customEvents);
            this.updateDom(this.config.animationSpeed);
        } else if (notification === "VOICE_EVENT_ADDED") {
            this.addCustomEvent(payload.event);
        } else if (notification === "OCR_EVENTS_EXTRACTED") {
            payload.events.forEach(event => {
                this.addCustomEvent(event);
            });
        }
    },

    notificationReceived: function(notification, payload, sender) {
        if (notification === "ADD_CALENDAR_EVENT") {
            this.addCustomEvent(payload);
        } else if (notification === "CALENDAR_REFRESH") {
            this.sendSocketNotification("FETCH_CALENDAR_DATA", this.config);
        }
    },

    getStyles: function() {
        return ["MMM-DaphneCalendar.css"];
    },

    getScripts: function() {
        return ["moment.js"];
    }
});

// Global object for calendar interactions
window.daphneCalendar = {
    showAddEventDialog: function() {
        console.log("Show add event dialog");
        // Implementation for add event dialog
    },
    
    startVoiceAdd: function() {
        console.log("Start voice event addition");
        // Trigger voice assistant for event addition
    },
    
    startOCRAdd: function() {
        console.log("Start OCR event addition");
        // Trigger camera/file upload for OCR processing
    },
    
    editEvent: function(eventId) {
        const modules = MM.getModules().withClass("MMM-DaphneCalendar");
        if (modules.length > 0) {
            modules[0].editEvent(eventId);
        }
    },
    
    deleteEvent: function(eventId) {
        const modules = MM.getModules().withClass("MMM-DaphneCalendar");
        if (modules.length > 0) {
            modules[0].deleteEvent(eventId);
        }
    }
};
