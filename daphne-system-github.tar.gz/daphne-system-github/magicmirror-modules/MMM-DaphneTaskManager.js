/* MagicMirror²
 * Module: MMM-DaphneTaskManager
 * Family Task Management System for Daphne Smart Display
 * 
 * By: Daphne System
 * MIT Licensed.
 */

Module.register("MMM-DaphneTaskManager", {
    defaults: {
        updateInterval: 60000, // Update every minute
        animationSpeed: 2000,
        fadeSpeed: 4000,
        maxTasksPerMember: 10,
        showCompletedTasks: true,
        confettiDuration: 3000,
        familyMembers: [
            { name: "Mom", color: "#FF6B6B", avatar: "👩" },
            { name: "Dad", color: "#4ECDC4", avatar: "👨" },
            { name: "Child1", color: "#45B7D1", avatar: "👧" },
            { name: "Child2", color: "#96CEB4", avatar: "👦" }
        ],
        taskCategories: [
            { name: "Chores", icon: "🏠", color: "#FFD93D" },
            { name: "School", icon: "📚", color: "#6BCF7F" },
            { name: "Personal", icon: "⭐", color: "#FF6B9D" },
            { name: "Family", icon: "👨‍👩‍👧‍👦", color: "#4ECDC4" }
        ]
    },

    requiresVersion: "2.1.0",

    start: function() {
        this.tasks = {};
        this.completedToday = {};
        this.lastResetDate = new Date().toDateString();
        
        // Initialize tasks for each family member
        this.config.familyMembers.forEach(member => {
            this.tasks[member.name] = [];
            this.completedToday[member.name] = [];
        });

        this.loaded = false;
        this.sendSocketNotification("LOAD_TASKS", this.config);
        this.scheduleUpdate();
    },

    getDom: function() {
        const wrapper = document.createElement("div");
        wrapper.className = "daphne-task-manager";

        if (!this.loaded) {
            wrapper.innerHTML = "Loading family tasks...";
            wrapper.className += " dimmed light small";
            return wrapper;
        }

        // Check if we need to reset daily tasks
        this.checkDailyReset();

        // Create header
        const header = document.createElement("div");
        header.className = "task-header";
        header.innerHTML = `
            <h2>📋 Family Tasks</h2>
            <div class="task-date">${new Date().toLocaleDateString('en-US', { 
                weekday: 'long', 
                year: 'numeric', 
                month: 'long', 
                day: 'numeric' 
            })}</div>
        `;
        wrapper.appendChild(header);

        // Create task grid for family members
        const taskGrid = document.createElement("div");
        taskGrid.className = "task-grid";

        this.config.familyMembers.forEach(member => {
            const memberCard = this.createMemberCard(member);
            taskGrid.appendChild(memberCard);
        });

        wrapper.appendChild(taskGrid);

        // Add task controls
        const controls = document.createElement("div");
        controls.className = "task-controls";
        controls.innerHTML = `
            <button class="task-btn add-task" onclick="daphneTaskManager.showAddTaskDialog()">
                ➕ Add Task
            </button>
            <button class="task-btn voice-add" onclick="daphneTaskManager.startVoiceAdd()">
                🎤 Voice Add
            </button>
        `;
        wrapper.appendChild(controls);

        return wrapper;
    },

    createMemberCard: function(member) {
        const card = document.createElement("div");
        card.className = "member-card";
        card.style.borderColor = member.color;

        const memberTasks = this.tasks[member.name] || [];
        const completedCount = this.completedToday[member.name]?.length || 0;
        const totalTasks = memberTasks.length;
        const pendingTasks = memberTasks.filter(task => !task.completed);

        card.innerHTML = `
            <div class="member-header" style="background-color: ${member.color}20">
                <span class="member-avatar">${member.avatar}</span>
                <span class="member-name">${member.name}</span>
                <span class="task-progress">${completedCount}/${totalTasks}</span>
            </div>
            <div class="task-list" id="tasks-${member.name}">
                ${this.renderTaskList(memberTasks, member)}
            </div>
        `;

        return card;
    },

    renderTaskList: function(tasks, member) {
        if (!tasks || tasks.length === 0) {
            return '<div class="no-tasks">No tasks today! 🎉</div>';
        }

        return tasks.map(task => {
            const category = this.config.taskCategories.find(cat => cat.name === task.category) || this.config.taskCategories[0];
            const isCompleted = task.completed;
            const isOverdue = !isCompleted && task.dueTime && new Date() > new Date(task.dueTime);

            return `
                <div class="task-item ${isCompleted ? 'completed' : ''} ${isOverdue ? 'overdue' : ''}" 
                     data-task-id="${task.id}" data-member="${member.name}">
                    <div class="task-checkbox" onclick="daphneTaskManager.toggleTask('${task.id}', '${member.name}')">
                        ${isCompleted ? '✅' : '⭕'}
                    </div>
                    <div class="task-content">
                        <div class="task-title">${task.title}</div>
                        <div class="task-meta">
                            <span class="task-category" style="color: ${category.color}">
                                ${category.icon} ${category.name}
                            </span>
                            ${task.dueTime ? `<span class="task-time">⏰ ${new Date(task.dueTime).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })}</span>` : ''}
                            ${task.recurrence ? `<span class="task-recurrence">🔄 ${task.recurrence}</span>` : ''}
                        </div>
                    </div>
                    <div class="task-actions">
                        <button class="task-action-btn edit" onclick="daphneTaskManager.editTask('${task.id}', '${member.name}')">✏️</button>
                        <button class="task-action-btn delete" onclick="daphneTaskManager.deleteTask('${task.id}', '${member.name}')">🗑️</button>
                    </div>
                </div>
            `;
        }).join('');
    },

    checkDailyReset: function() {
        const today = new Date().toDateString();
        if (this.lastResetDate !== today) {
            this.resetDailyTasks();
            this.lastResetDate = today;
        }
    },

    resetDailyTasks: function() {
        // Reset completed status for recurring tasks
        Object.keys(this.tasks).forEach(memberName => {
            this.tasks[memberName].forEach(task => {
                if (task.recurrence === 'daily' || task.recurrence === 'weekdays') {
                    const today = new Date().getDay();
                    if (task.recurrence === 'weekdays' && (today === 0 || today === 6)) {
                        return; // Skip weekends for weekday tasks
                    }
                    task.completed = false;
                }
            });
            this.completedToday[memberName] = [];
        });
        this.sendSocketNotification("SAVE_TASKS", this.tasks);
    },

    toggleTask: function(taskId, memberName) {
        const task = this.tasks[memberName].find(t => t.id === taskId);
        if (task) {
            task.completed = !task.completed;
            task.completedAt = task.completed ? new Date().toISOString() : null;

            if (task.completed) {
                this.completedToday[memberName].push(taskId);
                this.showConfetti();
                this.playCompletionSound();
            } else {
                this.completedToday[memberName] = this.completedToday[memberName].filter(id => id !== taskId);
            }

            this.sendSocketNotification("SAVE_TASKS", this.tasks);
            this.updateDom(this.config.animationSpeed);
        }
    },

    showConfetti: function() {
        // Create confetti animation
        const confetti = document.createElement("div");
        confetti.className = "confetti-container";
        confetti.innerHTML = "🎉🎊✨🌟💫⭐🎈🎁";
        document.body.appendChild(confetti);

        setTimeout(() => {
            document.body.removeChild(confetti);
        }, this.config.confettiDuration);
    },

    playCompletionSound: function() {
        // Play a pleasant completion sound
        const audio = new Audio('data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmwhBSuBzvLZiTYIG2m98OScTgwOUarm7blmGgU7k9n1unEiBC13yO/eizEIHWq+8+OWT');
        audio.play().catch(() => {}); // Ignore errors if audio can't play
    },

    addTask: function(memberName, taskData) {
        const newTask = {
            id: Date.now().toString(),
            title: taskData.title,
            category: taskData.category || 'Personal',
            dueTime: taskData.dueTime || null,
            recurrence: taskData.recurrence || 'none',
            completed: false,
            createdAt: new Date().toISOString()
        };

        if (!this.tasks[memberName]) {
            this.tasks[memberName] = [];
        }

        this.tasks[memberName].push(newTask);
        this.sendSocketNotification("SAVE_TASKS", this.tasks);
        this.updateDom(this.config.animationSpeed);
    },

    editTask: function(taskId, memberName) {
        const task = this.tasks[memberName].find(t => t.id === taskId);
        if (task) {
            this.sendNotification("SHOW_ALERT", {
                type: "notification",
                title: "Edit Task",
                message: `Editing: ${task.title}`,
                timer: 3000
            });
            // Implementation for edit dialog would go here
        }
    },

    deleteTask: function(taskId, memberName) {
        this.tasks[memberName] = this.tasks[memberName].filter(t => t.id !== taskId);
        this.sendSocketNotification("SAVE_TASKS", this.tasks);
        this.updateDom(this.config.animationSpeed);
    },

    scheduleUpdate: function() {
        setInterval(() => {
            this.updateDom(this.config.fadeSpeed);
        }, this.config.updateInterval);
    },

    socketNotificationReceived: function(notification, payload) {
        if (notification === "TASKS_LOADED") {
            this.tasks = payload.tasks || {};
            this.completedToday = payload.completedToday || {};
            this.loaded = true;
            this.updateDom(this.config.animationSpeed);
        } else if (notification === "VOICE_TASK_ADDED") {
            this.addTask(payload.member, payload.task);
        }
    },

    notificationReceived: function(notification, payload, sender) {
        if (notification === "ADD_TASK_VOICE") {
            // Handle voice-added tasks from Daphne voice assistant
            this.addTask(payload.member, payload.task);
        }
    },

    getStyles: function() {
        return ["MMM-DaphneTaskManager.css"];
    },

    getScripts: function() {
        return ["MMM-DaphneTaskManager-client.js"];
    }
});

// Global object for task manager interactions
window.daphneTaskManager = {
    showAddTaskDialog: function() {
        // Implementation for add task dialog
        console.log("Show add task dialog");
    },
    
    startVoiceAdd: function() {
        // Trigger voice assistant for task addition
        console.log("Start voice task addition");
    },
    
    toggleTask: function(taskId, memberName) {
        // Find the module instance and call its method
        const modules = MM.getModules().withClass("MMM-DaphneTaskManager");
        if (modules.length > 0) {
            modules[0].toggleTask(taskId, memberName);
        }
    },
    
    editTask: function(taskId, memberName) {
        const modules = MM.getModules().withClass("MMM-DaphneTaskManager");
        if (modules.length > 0) {
            modules[0].editTask(taskId, memberName);
        }
    },
    
    deleteTask: function(taskId, memberName) {
        const modules = MM.getModules().withClass("MMM-DaphneTaskManager");
        if (modules.length > 0) {
            modules[0].deleteTask(taskId, memberName);
        }
    }
};
