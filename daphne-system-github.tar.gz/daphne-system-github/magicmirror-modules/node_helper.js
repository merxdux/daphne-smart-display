/* node_helper.js
 * Node Helper for MMM-DaphneTaskManager
 * Handles task persistence and voice integration
 */

const NodeHelper = require("node_helper");
const fs = require("fs");
const path = require("path");

module.exports = NodeHelper.create({
    start: function() {
        console.log("Starting node helper for: " + this.name);
        this.tasksFile = path.join(__dirname, "tasks.json");
        this.config = null;
    },

    socketNotificationReceived: function(notification, payload) {
        console.log("Received notification: " + notification);

        switch (notification) {
            case "LOAD_TASKS":
                this.config = payload;
                this.loadTasks();
                break;
            case "SAVE_TASKS":
                this.saveTasks(payload);
                break;
            case "ADD_TASK_VOICE":
                this.addTaskFromVoice(payload);
                break;
            case "PROCESS_OCR_IMAGE":
                this.processOCRImage(payload);
                break;
        }
    },

    loadTasks: function() {
        try {
            if (fs.existsSync(this.tasksFile)) {
                const data = fs.readFileSync(this.tasksFile, "utf8");
                const taskData = JSON.parse(data);
                
                // Initialize completed today tracking
                const today = new Date().toDateString();
                if (!taskData.lastResetDate || taskData.lastResetDate !== today) {
                    taskData.completedToday = {};
                    taskData.lastResetDate = today;
                    
                    // Reset daily recurring tasks
                    this.resetDailyTasks(taskData.tasks);
                }

                this.sendSocketNotification("TASKS_LOADED", {
                    tasks: taskData.tasks || {},
                    completedToday: taskData.completedToday || {},
                    lastResetDate: taskData.lastResetDate
                });
            } else {
                // Create initial task structure
                const initialData = {
                    tasks: {},
                    completedToday: {},
                    lastResetDate: new Date().toDateString()
                };

                // Initialize with sample tasks for each family member
                if (this.config && this.config.familyMembers) {
                    this.config.familyMembers.forEach(member => {
                        initialData.tasks[member.name] = this.createSampleTasks(member.name);
                        initialData.completedToday[member.name] = [];
                    });
                }

                this.saveTasks(initialData.tasks, initialData);
                this.sendSocketNotification("TASKS_LOADED", initialData);
            }
        } catch (error) {
            console.error("Error loading tasks:", error);
            this.sendSocketNotification("TASKS_LOADED", {
                tasks: {},
                completedToday: {},
                lastResetDate: new Date().toDateString()
            });
        }
    },

    saveTasks: function(tasks, fullData = null) {
        try {
            let dataToSave;
            
            if (fullData) {
                dataToSave = fullData;
            } else {
                // Load existing data and update tasks
                let existingData = { tasks: {}, completedToday: {}, lastResetDate: new Date().toDateString() };
                if (fs.existsSync(this.tasksFile)) {
                    const data = fs.readFileSync(this.tasksFile, "utf8");
                    existingData = JSON.parse(data);
                }
                existingData.tasks = tasks;
                dataToSave = existingData;
            }

            fs.writeFileSync(this.tasksFile, JSON.stringify(dataToSave, null, 2));
            console.log("Tasks saved successfully");
        } catch (error) {
            console.error("Error saving tasks:", error);
        }
    },

    createSampleTasks: function(memberName) {
        const sampleTasks = {
            "Mom": [
                {
                    id: "mom_1",
                    title: "Review family budget",
                    category: "Personal",
                    dueTime: null,
                    recurrence: "weekly",
                    completed: false,
                    createdAt: new Date().toISOString()
                },
                {
                    id: "mom_2",
                    title: "Grocery shopping",
                    category: "Family",
                    dueTime: null,
                    recurrence: "weekly",
                    completed: false,
                    createdAt: new Date().toISOString()
                }
            ],
            "Dad": [
                {
                    id: "dad_1",
                    title: "Take out trash",
                    category: "Chores",
                    dueTime: null,
                    recurrence: "weekly",
                    completed: false,
                    createdAt: new Date().toISOString()
                },
                {
                    id: "dad_2",
                    title: "Check car maintenance",
                    category: "Personal",
                    dueTime: null,
                    recurrence: "monthly",
                    completed: false,
                    createdAt: new Date().toISOString()
                }
            ],
            "Child1": [
                {
                    id: "child1_1",
                    title: "Complete homework",
                    category: "School",
                    dueTime: "18:00",
                    recurrence: "weekdays",
                    completed: false,
                    createdAt: new Date().toISOString()
                },
                {
                    id: "child1_2",
                    title: "Clean bedroom",
                    category: "Chores",
                    dueTime: null,
                    recurrence: "weekly",
                    completed: false,
                    createdAt: new Date().toISOString()
                }
            ],
            "Child2": [
                {
                    id: "child2_1",
                    title: "Practice piano",
                    category: "Personal",
                    dueTime: "16:00",
                    recurrence: "daily",
                    completed: false,
                    createdAt: new Date().toISOString()
                },
                {
                    id: "child2_2",
                    title: "Feed pets",
                    category: "Chores",
                    dueTime: "08:00",
                    recurrence: "daily",
                    completed: false,
                    createdAt: new Date().toISOString()
                }
            ]
        };

        return sampleTasks[memberName] || [];
    },

    resetDailyTasks: function(tasks) {
        const today = new Date().getDay(); // 0 = Sunday, 6 = Saturday

        Object.keys(tasks).forEach(memberName => {
            if (tasks[memberName]) {
                tasks[memberName].forEach(task => {
                    if (task.recurrence === 'daily') {
                        task.completed = false;
                    } else if (task.recurrence === 'weekdays' && today >= 1 && today <= 5) {
                        task.completed = false;
                    }
                });
            }
        });
    },

    addTaskFromVoice: function(payload) {
        try {
            const { memberName, taskText, category, dueTime, recurrence } = payload;
            
            const newTask = {
                id: Date.now().toString(),
                title: taskText,
                category: category || 'Personal',
                dueTime: dueTime || null,
                recurrence: recurrence || 'none',
                completed: false,
                createdAt: new Date().toISOString(),
                addedBy: 'voice'
            };

            // Load current tasks
            let taskData = { tasks: {}, completedToday: {} };
            if (fs.existsSync(this.tasksFile)) {
                const data = fs.readFileSync(this.tasksFile, "utf8");
                taskData = JSON.parse(data);
            }

            if (!taskData.tasks[memberName]) {
                taskData.tasks[memberName] = [];
            }

            taskData.tasks[memberName].push(newTask);
            this.saveTasks(taskData.tasks, taskData);

            this.sendSocketNotification("VOICE_TASK_ADDED", {
                member: memberName,
                task: newTask
            });

            console.log(`Voice task added for ${memberName}: ${taskText}`);
        } catch (error) {
            console.error("Error adding voice task:", error);
        }
    },

    processOCRImage: function(payload) {
        try {
            const { imagePath, memberName } = payload;
            
            // This would integrate with the OCR pipeline
            // For now, we'll simulate the process
            console.log(`Processing OCR image: ${imagePath} for ${memberName}`);
            
            // In a real implementation, this would:
            // 1. Call the OCR service to extract text
            // 2. Parse the text for date/time/event information
            // 3. Create calendar events or tasks based on the content
            
            this.sendSocketNotification("OCR_PROCESSED", {
                success: true,
                message: "Image processed successfully",
                extractedEvents: []
            });
        } catch (error) {
            console.error("Error processing OCR image:", error);
            this.sendSocketNotification("OCR_PROCESSED", {
                success: false,
                message: "Error processing image",
                error: error.message
            });
        }
    },

    // Helper method to parse natural language task input
    parseTaskFromText: function(text) {
        const taskData = {
            title: text,
            category: 'Personal',
            dueTime: null,
            recurrence: 'none'
        };

        // Simple parsing logic - could be enhanced with NLP
        const lowerText = text.toLowerCase();

        // Detect categories
        if (lowerText.includes('homework') || lowerText.includes('study') || lowerText.includes('school')) {
            taskData.category = 'School';
        } else if (lowerText.includes('clean') || lowerText.includes('wash') || lowerText.includes('organize')) {
            taskData.category = 'Chores';
        } else if (lowerText.includes('family') || lowerText.includes('together')) {
            taskData.category = 'Family';
        }

        // Detect recurrence
        if (lowerText.includes('daily') || lowerText.includes('every day')) {
            taskData.recurrence = 'daily';
        } else if (lowerText.includes('weekly') || lowerText.includes('every week')) {
            taskData.recurrence = 'weekly';
        } else if (lowerText.includes('weekdays') || lowerText.includes('school days')) {
            taskData.recurrence = 'weekdays';
        }

        // Detect time (simple regex for time patterns)
        const timeMatch = text.match(/(\d{1,2}):(\d{2})\s*(am|pm)?/i);
        if (timeMatch) {
            taskData.dueTime = timeMatch[0];
        }

        return taskData;
    }
});
