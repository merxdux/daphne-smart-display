
'''
Daphne Voice Assistant

This script creates a wake-word activated voice assistant that runs locally on a Raspberry Pi.
It integrates with a local LLM (DeepSeek) and communicates with MagicMirror modules.

Features:
- Wake-word activation
- Speech-to-text transcription
- Local LLM for natural language understanding
- Text-to-speech for voice responses
- Integration with Daphne Task Manager and Calendar modules
'''

import os
import sys
import json
import time
import wave
import struct
from precise_runner import PreciseRunner, PreciseEngine
import pyaudio
from vosk import Model, KaldiRecognizer
import ollama
import piper

# --- Configuration ---

WAKE_WORD_MODEL_PATH = "/home/ubuntu/daphne-system/voice-assistant/model-output/daphne.model"
VOSK_MODEL_PATH = "/home/ubuntu/daphne-system/voice-assistant/vosk-model" # Path to Vosk model
PIPER_MODEL_PATH = "/home/ubuntu/daphne-system/voice-assistant/en_GB-alba-medium.onnx" # Path to Piper voice

# --- Main Assistant Class ---

class DaphneAssistant:
    def __init__(self):
        self.precise_runner = None
        self.pyaudio = None
        self.audio_stream = None
        self.vosk_model = None
        self.stt_recognizer = None
        self.piper_voice = None

        self.initialize_components()

    def initialize_components(self):
        '''Initialize all the necessary components for the voice assistant.'''
        try:
            # Initialize PyAudio for audio stream
            self.pyaudio = pyaudio.PyAudio()
            self.audio_stream = self.pyaudio.open(
                rate=16000,
                channels=1,
                format=pyaudio.paInt16,
                input=True,
                frames_per_buffer=1024
            )

            # Initialize Vosk for speech-to-text
            self.vosk_model = Model(VOSK_MODEL_PATH)

            # Initialize Piper for text-to-speech
            self.piper_voice = piper.PiperVoice.load(PIPER_MODEL_PATH)

            # Initialize Mycroft Precise for wake word detection
            self.precise_engine = PreciseEngine("/home/ubuntu/daphne-system/voice-assistant/mycroft-precise/.venv/bin/precise-engine", WAKE_WORD_MODEL_PATH)
            self.precise_runner = PreciseRunner(self.precise_engine, on_activation=self.on_wake_word_activation, stream=self.audio_stream)
            self.precise_runner.start()

            print("Daphne is ready and listening...")

        except Exception as e:
            print(f"Error initializing components: {e}")
            self.shutdown()

    def on_wake_word_activation(self):
        print("Wake word detected!")
        self.play_activation_sound()
        command = self.listen_for_command()
        if command:
            self.process_command(command)

    def run(self):
        '''Main loop to keep the assistant running.'''
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            print("Shutting down Daphne...")
        finally:
            self.shutdown()

    def listen_for_command(self):
        '''Listen for a command after the wake word is detected.'''
        self.stt_recognizer = KaldiRecognizer(self.vosk_model, 16000)
        print("Listening for a command...")

        start_time = time.time()
        while time.time() - start_time < 10:  # Listen for 10 seconds
            pcm = self.audio_stream.read(1024)
            if self.stt_recognizer.AcceptWaveform(pcm):
                result = json.loads(self.stt_recognizer.Result())
                command = result.get("text", "")
                if command:
                    print(f"Command received: {command}")
                    return command
        
        print("No command detected.")
        return None

    def process_command(self, command):
        '''Process the command using the local LLM.'''
        try:
            response = ollama.chat(
                model='deepseek-r1:1.5b',
                messages=[
                    {
                        'role': 'system',
                        'content': 'You are Daphne, a cheerful and helpful family assistant. Your responses should be kind, upbeat, and family-oriented. You can add tasks, create calendar events, and answer general knowledge questions.',
                    },
                    {
                        'role': 'user',
                        'content': command,
                    },
                ],
            )

            response_text = response['message']['content']
            print(f"Daphne's response: {response_text}")
            self.speak(response_text)

            # Check for actions (add task, create event, etc.)
            self.parse_and_execute_action(response_text, command)

        except Exception as e:
            print(f"Error processing command with LLM: {e}")
            self.speak("I'm sorry, I had trouble understanding that.")

    def parse_and_execute_action(self, response_text, command):
        '''Parse the LLM response and command to execute actions.'''
        # This is a simplified example. A more robust implementation would use
        # function calling or more sophisticated intent recognition.
        lower_command = command.lower()

        if "add task" in lower_command or "new task" in lower_command:
            # Extract task details and send to Task Manager module
            # Example: "add task for Dad to take out the trash"
            self.send_notification("ADD_TASK_VOICE", {"member": "Dad", "task": "take out the trash"})

        elif "add event" in lower_command or "new event" in lower_command:
            # Extract event details and send to Calendar module
            # Example: "add event for a family dinner on Friday at 7pm"
            self.send_notification("ADD_CALENDAR_EVENT", {"title": "Family Dinner", "startDate": "..."})

    def speak(self, text):
        '''Convert text to speech and play it.'''
        try:
            wav_file = wave.open("response.wav", "wb")
            self.piper_voice.synthesize(text, wav_file)
            wav_file.close()
            os.system("aplay response.wav")
        except Exception as e:
            print(f"Error during text-to-speech: {e}")

    def play_activation_sound(self):
        '''Play a sound to indicate that the wake word was detected.'''
        os.system("aplay activation.wav") # Assume activation.wav exists

    def send_notification(self, notification, payload):
        '''Send a socket notification to the MagicMirror modules.'''
        # This requires a way to communicate with the MagicMirror instance.
        # A simple approach is to write to a file that the node_helper reads,
        # or use a more direct communication method like WebSockets.
        print(f"Sending notification: {notification} with payload: {payload}")

    def shutdown(self):
        '''Clean up resources.'''
        if self.precise_runner:
            self.precise_runner.stop()
        if self.audio_stream:
            self.audio_stream.close()
        if self.pyaudio:
            self.pyaudio.terminate()

if __name__ == "__main__":
    assistant = DaphneAssistant()
    assistant.run()

