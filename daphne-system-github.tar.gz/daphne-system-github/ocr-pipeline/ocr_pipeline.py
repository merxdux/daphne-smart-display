
import pytesseract
from PIL import Image
import ollama

def extract_text_from_image(image_path):
    """Extracts text from an image using Tesseract OCR."""
    try:
        text = pytesseract.image_to_string(Image.open(image_path))
        return text
    except Exception as e:
        print(f"Error during OCR: {e}")
        return None

def extract_event_details(text):
    """Extracts event details from text using a local LLM."""
    try:
        response = ollama.chat(
            model='deepseek-r1:1.5b',
            messages=[
                {
                    'role': 'system',
                    'content': 'You are an expert at extracting event details from unstructured text. Your goal is to identify the event title, date, time, and location. Respond with a JSON object containing these details.',
                },
                {
                    'role': 'user',
                    'content': text,
                },
            ],
        )
        return response['message']['content']
    except Exception as e:
        print(f"Error extracting event details with LLM: {e}")
        return None

if __name__ == "__main__":
    image_path = "/home/ubuntu/upload/search_images/vuce6yJCyiuk.jpg"
    extracted_text = extract_text_from_image(image_path)
    if extracted_text:
        print("--- Extracted Text ---")
        print(extracted_text)
        print("\n--- Extracted Event Details ---")
        event_details = extract_event_details(extracted_text)
        if event_details:
            print(event_details)

