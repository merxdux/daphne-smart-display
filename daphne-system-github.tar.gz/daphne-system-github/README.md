# Daphne Smart Display

**A voice-activated AI assistant and family-oriented smart display powered by Raspberry Pi and MagicMirror².**

## Introduction

Daphne is a complete, plug-and-play smart display system designed for families. It provides a beautiful and intuitive interface for managing tasks, keeping track of calendar events, and interacting with a friendly, voice-activated AI assistant. The entire system runs locally on a Raspberry Pi, ensuring your family's privacy and data remain secure.

## Features

*   **MagicMirror² Interface:** A customizable and visually appealing display for all your family's information.
*   **Daphne Task Manager:** A shared to-do list for the whole family, with voice-activated task creation.
*   **Daphne Calendar:** A family calendar that can be updated with voice commands, with support for CalDAV-compatible calendars.
*   **Daphne Voice Assistant:** A cheerful and helpful AI assistant powered by a local Large Language Model (LLM), with a custom wake word ("Daphne").
*   **OCR-Powered Event Creation:** Add events to your calendar by simply showing a flyer or invitation to the camera.
*   **Privacy-Focused:** All components run locally on your Raspberry Pi, so your data never leaves your home.
*   **Easy Installation:** A simple, one-line installation script to get you up and running in minutes.

## System Architecture

The Daphne system is built on a modular architecture, with each component designed to work seamlessly with the others.

*   **MagicMirror²:** The core of the display, providing the user interface and module system.
*   **Custom Modules:** The `MMM-DaphneTaskManager` and `MMM-DaphneCalendar` modules provide the core functionality for task and calendar management.
*   **Voice Assistant:** A Python-based application that uses Mycroft Precise for wake word detection, Vosk for speech-to-text, a local LLM (DeepSeek) for natural language understanding, and Piper for text-to-speech.
*   **OCR Pipeline:** A Python script that uses Tesseract OCR to extract text from images and a local LLM to parse event details.
*   **Communication:** The voice assistant and OCR pipeline communicate with the MagicMirror modules through a simple notification system.

## Installation

To install the Daphne system, simply run the following command in your Raspberry Pi terminal:

```bash
bash -c "$(curl -sL https://raw.githubusercontent.com/your-github-username/daphne-system/main/install.sh)"
```

This will automatically download and install all the necessary components, including MagicMirror², the custom modules, the voice assistant, and the OCR pipeline.

## Configuration

After the installation is complete, you will need to configure your MagicMirror `config.js` file to include the new modules. You can find an example configuration in the `config` directory of this repository.

You will also need to configure the voice assistant with your specific details, such as the path to your wake word model.

## Usage

Once the system is installed and configured, you can start using it right away!

*   **Wake Word:** Say "Daphne" to activate the voice assistant.
*   **Voice Commands:**
    *   "Add a task for [family member] to [task description]."
    *   "Add an event for [event description] on [date] at [time]."
    *   Ask general knowledge questions.
*   **OCR Event Creation:** Simply hold a flyer or invitation up to the camera, and the system will automatically extract the event details and add them to your calendar.

## Contributing

Contributions are welcome! If you have any ideas for new features or improvements, please open an issue or submit a pull request.

## License

This project is licensed under the MIT License. See the `LICENSE` file for details.

