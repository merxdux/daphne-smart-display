#!/bin/bash

# Daphne Smart Display - Installation Script

# --- Banner ---
echo "=================================================="
echo "  Daphne Smart Display - Installation Script  "
echo "=================================================="
echo

# --- Update and Install Dependencies ---
echo "--- Updating package lists and installing dependencies ---"
sudo apt-get update
sudo apt-get install -y curl wget git python3-pip python3-venv

# --- Install MagicMirror² ---
echo "
--- Installing MagicMirror² ---"
bash -c "$(curl -sL https://raw.githubusercontent.com/sdetweil/MagicMirror_scripts/master/raspberry.sh)"

# --- Install Custom Modules ---
echo "
--- Installing custom Daphne modules ---"
cp -r magicmirror-modules/* ~/MagicMirror/modules/

# --- Install Voice Assistant ---
echo "
--- Installing Voice Assistant ---"
cd voice-assistant
python3 -m venv precise-venv
source precise-venv/bin/activate
pip3 install -r requirements.txt

# Download Vosk model
wget -q https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip
unzip vosk-model-small-en-us-0.15.zip
mv vosk-model-small-en-us-0.15 vosk-model
rm vosk-model-small-en-us-0.15.zip

# Download Piper voice
wget -q https://huggingface.co/rhasspy/piper-voices/resolve/main/en/en_GB/alba/medium/en_GB-alba-medium.onnx
wget -q https://huggingface.co/rhasspy/piper-voices/resolve/main/en/en_GB/alba/medium/en_GB-alba-medium.onnx.json

# --- Install OCR Pipeline ---
echo "
--- Installing OCR Pipeline ---"
cd ../ocr-pipeline
sudo apt-get install -y tesseract-ocr
pip3 install -r requirements.txt

# --- Install Ollama and DeepSeek Model ---
echo "
--- Installing Ollama and DeepSeek Model ---"
curl -fsSL https://ollama.com/install.sh | sh
ollama pull deepseek-r1:1.5b

echo "
--- Installation Complete! ---"
echo "Please configure your MagicMirror config.js file and restart MagicMirror."
echo "You may also need to configure the voice assistant with your specific details."

